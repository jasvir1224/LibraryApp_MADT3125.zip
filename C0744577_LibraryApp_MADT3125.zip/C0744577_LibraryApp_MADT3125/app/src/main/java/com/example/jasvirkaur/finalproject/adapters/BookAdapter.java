package com.example.jasvirkaur.finalproject.adapters;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.jasvirkaur.finalproject.R;
import com.example.jasvirkaur.finalproject.models.Book;

import java.util.ArrayList;
import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder>
{
    public BookAdapter(List<Book> bookArrayList) {
        this.bookArrayList = (ArrayList<Book>) bookArrayList;
    }

    public final class BookViewHolder extends RecyclerView.ViewHolder
    {
        TextView bookid;
        TextView name;
        TextView authorname;
        TextView yearofpublish;
        TextView totalpages;
        ImageView img;

        public BookViewHolder (@NonNull View holder)
        {
            super(holder);

            bookid = itemView.findViewById(R.id.avbook_id);
            name = itemView.findViewById(R.id.avbook_name);
            authorname = itemView.findViewById(R.id.avbook_author);
            yearofpublish = itemView.findViewById(R.id.avbook_year);
            totalpages = itemView.findViewById(R.id.avbook_totalpages);
            img = itemView.findViewById(R.id.avbook_img);

        }
    }

    private ArrayList<Book> bookArrayList;
    private Context context;

    public BookAdapter (Context context, ArrayList<Book> subs)
    {
        this.bookArrayList = subs;
        this.context = context;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder (@NonNull ViewGroup viewGroup, int i)
    {
        View itemView = LayoutInflater.from(this.context)
                .inflate(R.layout.available_books, viewGroup, false);

        BookViewHolder mVH = new BookViewHolder(itemView);
        return mVH;
    }

    @Override
    public void onBindViewHolder (@NonNull BookViewHolder bookViewHolder, int position)
    {
        Book book = this.bookArrayList.get(position);
        bookViewHolder.bookid.setText("Book ID: " + book.getBookID());
        bookViewHolder.name.setText("Book Name: "+ book.getName());
        bookViewHolder.authorname.setText("Author Name: " + book.getAuthorname());
        bookViewHolder.yearofpublish.setText("Year of Publish: " + book.getYearofpublish());
        bookViewHolder.totalpages.setText("Total Pages: " + book.getTotalpages());
        bookViewHolder.img.setImageResource(book.getBookPicture());

    }

    @Override
    public int getItemCount ()
    {
        return this.bookArrayList.size();
    }

}