package com.example.jasvirkaur.finalproject;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SMSActivity extends AppCompatActivity {
    @BindView(R.id.input_phone_number)
    EditText inputPhoneNumber;
    @BindView(R.id.input_layout_phone_number)
    TextInputLayout inputLayoutPhoneNumber;
    @BindView(R.id.input_text)
    EditText inputText;
    @BindView(R.id.input_layout_text)
    TextInputLayout inputLayoutText;
    @BindView(R.id.btnSms)
    Button btnSms;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        ButterKnife.bind(this);

    }


    @OnClick(R.id.btnSms)
    public void onViewClicked() {

        String message = inputText.getText().toString();
        String phoneNo = inputPhoneNumber.getText().toString();
        if(!TextUtils.isEmpty(message) && !TextUtils.isEmpty(phoneNo)) {
            Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phoneNo));
            smsIntent.putExtra("sms_body", message);
            if(smsIntent.resolveActivity(this.getPackageManager()) != null)
            {
                startActivity(smsIntent);
                Toast.makeText(this,"SMS Sent",Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(this,"No application to handle SMS",Toast.LENGTH_SHORT).show();
            }
        }

    }
}


