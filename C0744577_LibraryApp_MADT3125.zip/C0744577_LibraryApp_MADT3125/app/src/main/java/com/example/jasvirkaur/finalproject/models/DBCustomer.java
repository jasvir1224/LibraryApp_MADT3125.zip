package com.example.jasvirkaur.finalproject.models;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DBCustomer {
    public static final String TABLE_NAME = "tblCustomer";
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String EMAIL = "email";
    public static final String GENDER = "gender";
    public static final String Password = "password";

    private DBHelper dbHelper;

    public DBCustomer(Context context) {
        dbHelper = new DBHelper(context);
    }

    public void insert(Customer customer) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(ID, customer.getId());
        cv.put(NAME, customer.getName());
        cv.put(EMAIL, customer.getEmail());
        cv.put(GENDER, customer.getGender());
        cv.put(Password, customer.getPassword());

        db.insert(TABLE_NAME, null, cv);

        db.close();

    }

    public void update(Customer customer) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(ID, customer.getId());
        cv.put(NAME, customer.getName());
        cv.put(EMAIL, customer.getEmail());
        cv.put(GENDER, customer.getGender());
        cv.put(Password, customer.getPassword());
        db.update(TABLE_NAME, cv,
                ID + "=?",
                new String[]
                        {
                                String.valueOf(customer.getEmail())
                        });
        db.close();
    }

    public void deleteByID(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(TABLE_NAME, ID + "=?",
                new String[]
                        {
                                String.valueOf(id)
                        });
        db.close();
    }

    public void deleteByEmail(String email) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(TABLE_NAME, EMAIL + "=?",
                new String[]
                        {
                                email
                        });
        db.close();
    }

    public ArrayList<Customer> getAllCustomer() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        //Cursor mCursor = db.query(TABLE_NAME, null, null, null, null, null, null, null);
        Cursor mCursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        ArrayList<Customer> customers = new ArrayList<>();
        if (mCursor != null) {
            if (mCursor.getCount() != 0) {
                mCursor.moveToFirst();
                while (!mCursor.isAfterLast()) {
                    Customer customer = new Customer();
                    customer.setEmail(mCursor.getString(0));
                    customer.setName(mCursor.getString(1));
                    customer.setGender(mCursor.getString(2));
                    customer.setPassword(mCursor.getString(3));

                    customers.add(customer);

                    mCursor.moveToNext();
                }
            }
        }

        db.close();
        return customers;
    }


}
