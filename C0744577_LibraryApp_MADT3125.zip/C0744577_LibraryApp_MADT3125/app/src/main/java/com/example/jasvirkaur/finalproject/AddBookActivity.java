package com.example.jasvirkaur.finalproject;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import com.example.jasvirkaur.finalproject.models.Book;
import com.example.jasvirkaur.finalproject.models.DBBook;
import com.example.jasvirkaur.finalproject.models.DBHelper;

import java.util.ArrayList;
import java.util.Calendar;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AddBookActivity extends AppCompatActivity {

    @BindView(R.id.book_name)
    TextView bookName;
    @BindView(R.id.author_name)
    TextView authorName;
    DBHelper sqLiteDatabase;

    EditText selectDate;
    private int mYear, mMonth, mDay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);
        ButterKnife.bind(this);
        String name = bookName.toString();
        String authorname = authorName.toString();
        selectDate = findViewById(R.id.date);

        sqLiteDatabase = new DBHelper(getApplicationContext());
        boolean getbooks = sqLiteDatabase.getbooks(name, authorname);

        Intent previousPage = getIntent();
        Bundle params = previousPage.getExtras();
        int bookId = params.getInt("bookId");

        DBBook bdBook = new DBBook(this);
        ArrayList<Book> allBooks = bdBook.getAllBooks();

        Book book = new Book();

        for (Book bk : allBooks) {
            if (bk.getBookID() == bookId) book = bk;
        }

        bookName.setText(book.getName());
        authorName.setText(book.getAuthorname());

    }
  /*  @Override
        public void onClick(View view) {


        if (view == selectDate) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);


                DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                selectDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }*/

    }

