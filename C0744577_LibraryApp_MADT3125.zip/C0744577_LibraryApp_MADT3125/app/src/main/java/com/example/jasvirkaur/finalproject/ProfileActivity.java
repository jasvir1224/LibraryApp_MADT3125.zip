package com.example.jasvirkaur.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.jasvirkaur.finalproject.models.Book;
import com.example.jasvirkaur.finalproject.models.Customer;
import com.example.jasvirkaur.finalproject.models.DBBook;
import com.example.jasvirkaur.finalproject.models.DBCustomer;
import com.example.jasvirkaur.finalproject.models.DBHelper;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ProfileActivity extends AppCompatActivity {


    @BindView(R.id.pro_name)
    TextView proName;
    @BindView(R.id.pro_email)
    TextView proEmail;
    @BindView(R.id.pro_password)
    TextView propassword;
    @BindView(R.id.pro_gender)
    TextView progender;

    DBHelper sqLiteDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        ButterKnife.bind(this);
        //Bundle bundle = getIntent().getExtras();
       // String customer = bundle.getString("customer");


       // sqLiteDatabase = new DBHelper(getApplicationContext());


        Intent previousPage = getIntent();
        Bundle params = previousPage.getExtras();
        String email = params.getString("email");

        DBCustomer dbCustomer = new DBCustomer(this);
        ArrayList<Customer> allcustomers = dbCustomer.getAllCustomer();

        Customer customer = new Customer();

        for (Customer cust : allcustomers) {
            if (cust.getEmail() == email) customer = cust;
        }

        proName.setText(customer.getName());
        proEmail.setText(customer.getEmail());
        propassword.setText(customer.getPassword());
        progender.setText(customer.getGender());


    }
}
