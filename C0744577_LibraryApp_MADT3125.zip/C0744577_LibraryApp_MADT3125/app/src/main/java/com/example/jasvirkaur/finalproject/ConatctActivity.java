package com.example.jasvirkaur.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class ConatctActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conatct);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.contact_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.contact_sms:
                Toast.makeText(this, "add", Toast.LENGTH_SHORT);
                Intent intent = new Intent(ConatctActivity.this, SMSActivity.class);
                startActivity(intent);
                break;
            case R.id.contact_call:
                Toast.makeText(this, "Delete", Toast.LENGTH_SHORT);
                Intent intent1 = new Intent(ConatctActivity.this, CallActivity.class);
                startActivity(intent1);
                break;
            case R.id.contact_email:
                Toast.makeText(this, "Next", Toast.LENGTH_SHORT);
                Intent intent2 = new Intent(ConatctActivity.this, EmailActivity.class);
                startActivity(intent2);
                break;
        }


        return super.onOptionsItemSelected(item);
    }
}
