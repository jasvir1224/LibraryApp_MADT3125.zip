package com.example.jasvirkaur.finalproject;

import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

import java.io.IOException;
import java.io.InputStream;

public class InstructionActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instruction);

        webView = findViewById(R.id.wwInstruction);

        AssetManager massetManager= this.getAssets();
        try {
            InputStream inputStream =  massetManager.open("instruction.html");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            String content = new String(buffer, "UTF-8");
            webView.loadData(content,"text/html", "utf8");

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    }

