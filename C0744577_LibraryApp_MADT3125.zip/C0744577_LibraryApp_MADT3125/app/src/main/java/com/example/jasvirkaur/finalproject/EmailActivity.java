package com.example.jasvirkaur.finalproject;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class EmailActivity extends AppCompatActivity {

    @BindView(R.id.input_email)
    EditText inputEmail;
    @BindView(R.id.input_layout_email)
    TextInputLayout inputLayoutEmail;
    @BindView(R.id.input_subject)
    EditText inputSubject;
    @BindView(R.id.input_layout_subject)
    TextInputLayout inputLayoutSubject;
    @BindView(R.id.input_body)
    EditText inputBody;
    @BindView(R.id.input_layout_body)
    TextInputLayout inputLayoutBody;
    @BindView(R.id.btnEmail)
    Button btnEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.btnEmail)
    public void onViewClicked() {
        String to = inputEmail.getText().toString();
        String subject = inputSubject.getText().toString();
        String body = inputBody.getText().toString();

        Intent emailIntent = new Intent(Intent.ACTION_SEND); //Intent.ACTION_SENDTO
        emailIntent.setType("text/plain");
        emailIntent.setData(Uri.parse("mailto:" + to));
        //emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{ to});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, body);
        emailIntent.setType("message/rfc822");


        if(emailIntent.resolveActivity(this.getPackageManager()) != null)
        {
            startActivity(Intent.createChooser(emailIntent, "Select Email Client"));
        }
        else
        {
            Toast.makeText(this,"No application to handle Email",Toast.LENGTH_SHORT).show();
        }
    }
}


