package com.example.jasvirkaur.finalproject.models;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DBBook {
    public static final String TABLE_NAME = "tblBook";
    public static final String BOOKID = "bookid";
    public static final String NAME = "name";
    public static final String AUTHORNAME = "authorname";
    public static final String YEAROFPUBLISH = "yearofpublish";
    public static final String TOTALPAGES = "totalpages";



    private DBHelper dbHelper;

    public DBBook(Context context) {
        dbHelper = new DBHelper(context);
    }

    public void insert(Book book) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(BOOKID,book.getBookID());
        cv.put(NAME, book.getName());
        cv.put(AUTHORNAME, book.getAuthorname());
        cv.put(YEAROFPUBLISH, book.getYearofpublish());
        cv.put(TOTALPAGES, book.getTotalpages());

        db.insert(TABLE_NAME, null, cv);

        db.close();

    }

    public void update(Book book) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(BOOKID,book.getBookID());
        cv.put(NAME, book.getName());
        cv.put(AUTHORNAME, book.getAuthorname());
        cv.put(YEAROFPUBLISH, book.getYearofpublish());
        cv.put(TOTALPAGES, book.getTotalpages());
        db.update(TABLE_NAME, cv,
                BOOKID + "=?",
                new String[]
                        {
                                String.valueOf(book.getBookID())
                        });
        db.close();
    }

    public void deleteByID(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(TABLE_NAME, BOOKID + "=?",
                new String[]
                        {
                                String.valueOf(id)
                        });
        db.close();
    }

    public void deleteByName(String name) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(TABLE_NAME, NAME + "=?",
                new String[]
                        {
                                name
                        });
        db.close();
    }

    public ArrayList<Book> getAllBooks() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor mCursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        ArrayList<Book> books = new ArrayList<>();
        if (mCursor != null) {
            if (mCursor.getCount() != 0) {
                mCursor.moveToFirst();
                while (!mCursor.isAfterLast()) {
                    Book book = new Book();
                    book.setBookID(mCursor.getInt(0));
                    book.setName(mCursor.getString(1));
                    book.setAuthorname(mCursor.getString(2));
                    book.setYearofpublish(mCursor.getInt(3));
                    book.setTotalpages(mCursor.getInt(4));

                    books.add(book);

                    mCursor.moveToNext();
                }
            }
        }

        db.close();
        return books;
    }


}


