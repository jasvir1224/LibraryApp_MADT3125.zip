package com.example.jasvirkaur.finalproject.models;

public class Book {

    private int bookID;
    private String name;
    private String authorname;
    private int yearofpublish;
    private int totalpages;
    private int bookPicture;

    public Book() {
    }



    public Book(int bookID, String name, String authorname, int yearofpublish, int totalpages, int bookPicture) {
        this.bookID = bookID;

        this.name = name;
        this.authorname = authorname;
        this.yearofpublish = yearofpublish;
        this.totalpages = totalpages;
        this.bookPicture = bookPicture;
    }

    public int getBookID() {
        return bookID;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthorname() {
        return authorname;
    }

    public void setAuthorname(String authorname) {
        this.authorname = authorname;
    }

    public int getYearofpublish() {
        return yearofpublish;
    }

    public void setYearofpublish(int yearofpublish) {
        this.yearofpublish = yearofpublish;
    }

    public int getTotalpages() {
        return totalpages;
    }

    public void setTotalpages(int totalpages) {
        this.totalpages = totalpages;
    }

    public int getBookPicture() {
        return bookPicture;
    }

    public void setBookPicture(int bookPicture) {
        this.bookPicture = bookPicture;
    }
}
