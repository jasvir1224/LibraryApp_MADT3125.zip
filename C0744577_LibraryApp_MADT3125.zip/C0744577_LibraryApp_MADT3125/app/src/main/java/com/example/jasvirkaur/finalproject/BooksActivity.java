package com.example.jasvirkaur.finalproject;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.example.jasvirkaur.finalproject.adapters.BookAdapter;
import com.example.jasvirkaur.finalproject.models.Book;
import com.example.jasvirkaur.finalproject.models.Customer;
import com.example.jasvirkaur.finalproject.models.DBBook;
import com.example.jasvirkaur.finalproject.models.DBCustomer;
import com.example.jasvirkaur.finalproject.models.DBHelper;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class BooksActivity extends AppCompatActivity {

    @BindView(R.id.recyclerview)
    RecyclerView recyclerView;

    private ArrayList<Book> bookArrayList = new ArrayList<>();
    private BookAdapter bookadapter;

    DBHelper sqLiteDatabase;
    private DBBook dbBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_books);
        ButterKnife.bind(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
      // setSupportActionBar(toolbar);

        sqLiteDatabase = new DBHelper(getApplicationContext());
        insertDefaultBook();
        dbBook = new DBBook(getApplicationContext());
        bookArrayList = dbBook.getAllBooks();

        //recyclerView = (RecyclerView) findViewById(R.id.recyclerview);

        bookadapter = new BookAdapter(this, bookArrayList);

        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());

        // horizontal RecyclerView
        // keep movie_list_row.xml width to `wrap_content`
        // RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);

        recyclerView.setLayoutManager(mLayoutManager);

        // adding inbuilt divider line
      // recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        // adding custom divider line with padding 16dp
       recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.HORIZONTAL));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        recyclerView.setAdapter(bookadapter);

        // row click listener
       recyclerView.addOnItemTouchListener(new RecycleTouchListener(getApplicationContext(), recyclerView, new RecycleTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Book book = bookArrayList.get(position);
                Toast.makeText(getApplicationContext(), book.getBookID() + " is selected!", Toast.LENGTH_SHORT).show();

                if (book.getBookID() != 0){

                    Intent intent1 = new Intent(BooksActivity.this, AddBookActivity.class);
                    intent1.putExtra("bookId", book.getBookID());
                    startActivity(intent1);

                }
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
    }
    public void insertDefaultBook()
    {
        DBBook dbBook = new DBBook(this);
        // 01
        Book book = new Book();
        book.setBookID(01);
        book.setName("Rivers of London");
        book.setAuthorname("Ben Aaronovitch");
        book.setYearofpublish(2011);
        book.setTotalpages(392);
        book.setBookPicture(R.drawable.rivers_of_london);
        dbBook.insert(book);

        //02
        book.setBookID(02);
        book.setName("Flatland");
        book.setAuthorname("Edwin Abbott Abbott");
        book.setYearofpublish(1926);
        book.setTotalpages(294);
        book.setBookPicture(R.drawable.flatland);
        dbBook.insert(book);
        //03


        book.setBookID(03);
        book.setName(" The Act of Roger Murgatroyd");
        book.setAuthorname("Gilbert Adair");
        book.setYearofpublish(2006);
        book.setTotalpages(286);
        book.setBookPicture(R.drawable.murgatroyd);
        dbBook.insert(book);

        //04
        book.setBookID(4);
        book.setName("A Closed Book");
        book.setAuthorname("Gilbert Adair");
        book.setYearofpublish(1999);
        book.setTotalpages(258);
        book.setBookPicture(R.drawable.a_closed_book);
        dbBook.insert(book);

        //05
        book.setBookID(5);
        book.setName("The Information");
        book.setAuthorname("Martin Amis");
        book.setYearofpublish(1995);
        book.setTotalpages(494);
        book.setBookPicture(R.drawable.information);
        dbBook.insert(book);


        //06
        book.setBookID(6);
        book.setName("A Midsummer Tempest");
        book.setAuthorname("Poul Anderson");
        book.setYearofpublish(1974);
        book.setTotalpages(207);
        book.setBookPicture(R.drawable.midsumtemp);
        dbBook.insert(book);


        //07
        book.setBookID(7);
        book.setName("The Foundation Series");
        book.setAuthorname("Isaac Asimov");
        book.setYearofpublish(1993);
        book.setTotalpages(340);
        book.setBookPicture(R.drawable.foundation);
        dbBook.insert(book);

        //08
        book.setBookID(8);
        book.setName("Emotionally Weird");
        book.setAuthorname("Kate Atkinson");
        book.setYearofpublish(2000);
        book.setTotalpages(352);
        book.setBookPicture(R.drawable.emotionallyweird);
        dbBook.insert(book);


        //09
        book.setBookID(9);
        book.setName("The Blind Assassin");
        book.setAuthorname("Margaret Atwood");
        book.setYearofpublish(2000);
        book.setTotalpages(536);
        book.setBookPicture(R.drawable.blind);
        dbBook.insert(book);


    }


}




