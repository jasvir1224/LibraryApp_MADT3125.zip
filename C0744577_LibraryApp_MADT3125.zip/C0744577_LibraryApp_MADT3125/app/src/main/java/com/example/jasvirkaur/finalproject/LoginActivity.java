package com.example.jasvirkaur.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jasvirkaur.finalproject.models.DBHelper;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class LoginActivity extends AppCompatActivity {


    DBHelper sqLiteDatabase;
    @BindView(R.id.email)
    EditText email;
    @BindView(R.id.password)
    EditText password;
    @BindView(R.id.rememberme)
    CheckBox rememberme;
    @BindView(R.id.login)
    Button login;
    @BindView(R.id.register)
    Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        sqLiteDatabase = new DBHelper(getApplicationContext());
        //sqLiteDatabase.onUpgrade(sqLiteDatabase.getWritableDatabase(), 0, 0);
        //sqLiteDatabase.onCreate(sqLiteDatabase.getWritableDatabase());
        ButterKnife.bind(this);
    }

    @OnClick(R.id.login)
    public void onViewClicked() {

        String emailid = email.getText().toString();
        String passWord = password.getText().toString();
        boolean emailpassword = sqLiteDatabase.emailpassword(emailid, passWord);
        if (emailpassword == true) {
            Toast.makeText(getApplicationContext(), "Successfully Login", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(getApplicationContext(), "Wrong Email or Password", Toast.LENGTH_SHORT).show();

        }
    }

    @OnClick(R.id.register)
    public void onViewClicked1() {

        Toast.makeText(getApplicationContext(), "Register", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
        startActivity(intent);
    }


}


