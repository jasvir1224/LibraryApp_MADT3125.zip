package com.example.jasvirkaur.finalproject;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class CallActivity extends AppCompatActivity {

    @BindView(R.id.input_phone_number)
    EditText inputPhoneNumber;
    @BindView(R.id.input_layout_phone_number)
    TextInputLayout inputLayoutPhoneNumber;
    @BindView(R.id.btnPhoneCall)
    Button btnPhoneCall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);
        ButterKnife.bind(this);

    }
    @OnClick(R.id.btnPhoneCall)
    public void onViewClicked() {
        String phoneNo = inputPhoneNumber.getText().toString();
        if(!TextUtils.isEmpty(phoneNo)) {
            String dial = "tel:" + phoneNo;
            Intent phoneItent = new Intent(Intent.ACTION_DIAL, Uri.parse(dial));
            if(phoneItent.resolveActivity(this.getPackageManager()) != null)
            {
                startActivity(phoneItent);
            }
            else
            {
                Toast.makeText(this,"No application to handle Phone call",Toast.LENGTH_SHORT).show();
            }
        }else {
            Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show();
        }
    }
}


