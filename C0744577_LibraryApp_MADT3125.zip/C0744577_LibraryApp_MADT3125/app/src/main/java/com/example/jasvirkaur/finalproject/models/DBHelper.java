package com.example.jasvirkaur.finalproject.models;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "dbCustomer";
    private static final int DB_VERSION = 1;
    public Context cnt;

    public DBHelper(Context context)
    {
        super(context, DB_NAME, null, DB_VERSION);
        this.cnt = context;
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String studentTable = "CREATE TABLE " + DBCustomer.TABLE_NAME
                + "(" + DBCustomer.EMAIL + " TEXT PRIMARY KEY,"
                + DBCustomer.NAME + " TEXT,"
                + DBCustomer.ID + " Int,"
                + DBCustomer.GENDER + " TEXT,"
                + DBCustomer.Password + " TEXT)";

        sqLiteDatabase.execSQL(studentTable);

        String bookTable = "CREATE TABLE " + DBBook.TABLE_NAME
                + "(" + DBBook.BOOKID + " INT PRIMARY KEY,"
                + DBBook.NAME + " TEXT,"
                + DBBook.AUTHORNAME + " TEXT,"
                + DBBook.YEAROFPUBLISH + " INT,"
                + DBBook.TOTALPAGES + " INT)";

        sqLiteDatabase.execSQL(bookTable);

       // this.insertDefaultUser(sqLiteDatabase);
       // this.insertDefaultBooks(sqLiteDatabase);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE " + DBCustomer.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE " + DBBook.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }


    public boolean emailpassword(String email,String password){

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from " + DBCustomer.TABLE_NAME + " where email=? and password=?",new  String[]{email,password});
        if (cursor.getCount()>0) return true;
        else return false;
    }

    public boolean getbooks(String name,String authorname){

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from " + DBBook.TABLE_NAME + " where name=? and authorname=?", new  String[]{name, authorname});
        if (cursor.getCount()>0) return true;
        else return false;
    }

    /*public void insertDefaultUser(SQLiteDatabase sqLiteDatabase)
    {
        Customer user = new Customer();
        user.setId(1);
        user.setName("Jasvir");
        user.setEmail("1");
        user.setPassword("1");
        DBCustomer cust = new DBCustomer(this.cnt);
        //cust.insert(user);
    }*/


}
